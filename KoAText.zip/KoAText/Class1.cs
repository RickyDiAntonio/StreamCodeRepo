﻿using System;

namespace Part_3_and_final
{
    public class Class1
    {
        public Class1()
        {
            new Game game();
        }
    }
}

