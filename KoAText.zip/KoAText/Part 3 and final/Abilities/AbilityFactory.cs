﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3_and_final.Abilities
{
    public static class AbilityFactory
    {
        // public Ability(string name, EffectTypes type, string text,int reqLevel,int manaCost =0,params EffectTypes[] extraEffects)
        public static Ability CreateAbility(AbilityNames abilityName)
        {
            return abilityName switch
            {
                //basic /weapon abilities
                AbilityNames.basicAttack => new Ability("Basic Attack", EffectTypes.damage, " performs a basic attack", 0),

                //Sorcery
                AbilityNames.healingSurge => new Ability("Healing Surge",EffectTypes.heal," channels healing energies",1,50),
                AbilityNames.stormbolt => new Ability("Storm Bolt", EffectTypes.damage, " hurls a bolt of arcane energy", 1,25),                
                AbilityNames.flameMark=> new Ability("Flame Mark",EffectTypes.DoT," sears a flaming rune on the enemy",1),
                
                AbilityNames.sphereOfProtection=> new Ability("Sphere of Protection",EffectTypes.shield, " is encased in a shimmering bubble",2),
                //Might

                //finesse

                //effects dot
                AbilityNames.flameMarkDoT => new Ability("Flame Mark", EffectTypes.DoT, " takes damage from flame mark", 0),

                _ => throw new ArgumentOutOfRangeException(nameof(abilityName), $"Unknown ability: {abilityName}")

            };
        }
    }
}
