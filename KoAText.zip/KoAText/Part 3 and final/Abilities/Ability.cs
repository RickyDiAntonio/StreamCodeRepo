﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_3_and_final
{
    public class Ability
    {
        //elements, manacosts
        public string name { get; private set; }
        public EffectTypes type { get; private set; }
        public string text = "";
        public int reqLevel { get; }
        public int manaCost { get; private set; }
        public EffectTypes[] extraEffects { get; private set; }
        
        public Ability(string name, EffectTypes type, string text,int reqLevel,int manaCost =0,params EffectTypes[] extraEffects) { 
            this.name = name;
            this.type = type;
            this.text = text;
            this.reqLevel = reqLevel;
            this.extraEffects = extraEffects ?? new EffectTypes[0];
            this.manaCost = manaCost;
        }
       

    }
}
